
export const getStaticImage = (path) =>{
    return process.env.REACT_APP_STATIC_STORAGE+path;
}