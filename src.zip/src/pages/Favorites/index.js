import { Page } from "../../components/Page";
import { ShortMenu } from "../../components/ShortMenu";

export const Favorites =()=>(
    <Page>
        <ShortMenu/>
        <p>favoritos...</p>
    </Page>

)