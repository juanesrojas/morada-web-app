import { createContext } from "react";

const sampleVariable = "Juan";

export const SampleContext = createContext(sampleVariable);