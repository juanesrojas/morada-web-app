import styled from 'styled-components';

export const PageWrapper = styled.section`
    margin: 10px auto 90px; 
    width:80%;
    //margin:auto;


   
`;