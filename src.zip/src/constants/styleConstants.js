export const MENU_HEIGHT = 80;
export const PRIMARY_COLOR = '#4A148C';